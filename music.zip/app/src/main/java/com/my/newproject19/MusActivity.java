package com.my.newproject19;

import android.app.Activity;
import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.io.*;
import java.util.*;
import java.util.regex.*;
import java.text.*;
import org.json.*;
import java.util.ArrayList;
import java.util.HashMap;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.media.MediaPlayer;
import java.util.Timer;
import java.util.TimerTask;
import android.widget.AdapterView;
import android.view.View;
import android.app.Fragment;
import android.app.FragmentManager;
import android.app.DialogFragment;
import android.Manifest;
import android.content.pm.PackageManager;

public class MusActivity extends Activity {
	
	private Timer _timer = new Timer();
	
	private String data = "";
	private double current = 0;
	private String play = "";
	private double nr = 0;
	private String currentFilePath = "";
	private String name = "";
	private double trash = 0;
	private double trash2 = 0;
	
	private ArrayList<String> list = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> listmap = new ArrayList<>();
	
	private LinearLayout linear1;
	private LinearLayout linear5;
	private LinearLayout linear3;
	private LinearLayout linear6;
	private LinearLayout linear2;
	private TextView textview1;
	private ImageView imageview1;
	private ListView listview1;
	private ImageView imageview2;
	private LinearLayout linear4;
	private ImageView imageview3;
	private ImageView imageview4;
	private TextView textview2;
	private TextView textview3;
	
	private MediaPlayer mp;
	private TimerTask run;
	private TimerTask trasher;
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.mus);
		initialize(_savedInstanceState);
		
		if (Build.VERSION.SDK_INT >= 23) {
			if (checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED) {
				requestPermissions(new String[] {Manifest.permission.READ_EXTERNAL_STORAGE}, 1000);
			} else {
				initializeLogic();
			}
		} else {
			initializeLogic();
		}
	}
	
	@Override
	public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
		super.onRequestPermissionsResult(requestCode, permissions, grantResults);
		if (requestCode == 1000) {
			initializeLogic();
		}
	}
	
	private void initialize(Bundle _savedInstanceState) {
		linear1 = findViewById(R.id.linear1);
		linear5 = findViewById(R.id.linear5);
		linear3 = findViewById(R.id.linear3);
		linear6 = findViewById(R.id.linear6);
		linear2 = findViewById(R.id.linear2);
		textview1 = findViewById(R.id.textview1);
		imageview1 = findViewById(R.id.imageview1);
		listview1 = findViewById(R.id.listview1);
		imageview2 = findViewById(R.id.imageview2);
		linear4 = findViewById(R.id.linear4);
		imageview3 = findViewById(R.id.imageview3);
		imageview4 = findViewById(R.id.imageview4);
		textview2 = findViewById(R.id.textview2);
		textview3 = findViewById(R.id.textview3);
		
		linear2.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				
			}
		});
		
		listview1.setOnItemClickListener(new AdapterView.OnItemClickListener() {
			@Override
			public void onItemClick(AdapterView<?> _param1, View _param2, int _param3, long _param4) {
				final int _position = _param3;
				if (play.equals("yes")) {
					mp.pause();
					current = _position;
					textview2.setText(listmap.get((int)current).get("path").toString().replace(".mp3", ""));
					linear2.setVisibility(View.VISIBLE);
					java.io.File mpFile = new File(getCacheDir(), listmap.get((int)current).get("path").toString());
					if (!mpFile.exists()) {
						try {
							java.io.InputStream mpIS = getAssets().open(listmap.get((int)current).get("path").toString()); 
							java.io.FileOutputStream mpFOS = null;
							mpFOS = new FileOutputStream(mpFile);
							final byte[] mpByte = new byte[1024];
							int mpint;
							while ((mpint = mpIS.read(mpByte)) != -1) {
								mpFOS.write(mpByte, 0, mpint); } 
							mpIS.close();
							mpFOS.close();
						} catch (Exception e) {} }
					mp = MediaPlayer.create(getApplicationContext(), Uri.fromFile(new java.io.File(mpFile.getAbsolutePath())));
					mp.start();
					run = new TimerTask() {
						@Override
						public void run() {
							runOnUiThread(new Runnable() {
								@Override
								public void run() {
									if (mp.isPlaying()) {
										imageview3.setImageResource(R.drawable.pla_3);
									}
									else {
										imageview3.setImageResource(R.drawable.pla_4);
									}
								}
							});
						}
					};
					_timer.scheduleAtFixedRate(run, (int)(0), (int)(100));
				}
				else {
					current = _position;
					textview2.setText(listmap.get((int)current).get("path").toString().replace(".mp3", ""));
					linear2.setVisibility(View.VISIBLE);
					java.io.File mpFile = new File(getCacheDir(), listmap.get((int)current).get("path").toString());
					if (!mpFile.exists()) {
						try {
							java.io.InputStream mpIS = getAssets().open(listmap.get((int)current).get("path").toString()); 
							java.io.FileOutputStream mpFOS = null;
							mpFOS = new FileOutputStream(mpFile);
							final byte[] mpByte = new byte[1024];
							int mpint;
							while ((mpint = mpIS.read(mpByte)) != -1) {
								mpFOS.write(mpByte, 0, mpint); } 
							mpIS.close();
							mpFOS.close();
						} catch (Exception e) {} }
					mp = MediaPlayer.create(getApplicationContext(), Uri.fromFile(new java.io.File(mpFile.getAbsolutePath())));
					mp.start();
					play = "yes";
					run = new TimerTask() {
						@Override
						public void run() {
							runOnUiThread(new Runnable() {
								@Override
								public void run() {
									if (mp.isPlaying()) {
										imageview3.setImageResource(R.drawable.pla_3);
									}
									else {
										imageview3.setImageResource(R.drawable.pla_4);
									}
								}
							});
						}
					};
					_timer.scheduleAtFixedRate(run, (int)(0), (int)(100));
				}
			}
		});
		
		imageview3.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (mp.isPlaying()) {
					mp.pause();
					imageview3.setImageResource(R.drawable.pla_4);
				}
				else {
					mp.start();
					imageview3.setImageResource(R.drawable.pla_3);
				}
			}
		});
		
		imageview4.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (current == (listmap.size() - 1)) {
					SketchwareUtil.showMessage(getApplicationContext(), "last song");
				}
				else {
					mp.pause();
					current = current + 1;
					textview2.setText(listmap.get((int)current).get("path").toString().replace(".mp3", ""));
					java.io.File mpFile = new File(getCacheDir(), listmap.get((int)current).get("path").toString());
					if (!mpFile.exists()) {
						try {
							java.io.InputStream mpIS = getAssets().open(listmap.get((int)current).get("path").toString()); 
							java.io.FileOutputStream mpFOS = null;
							mpFOS = new FileOutputStream(mpFile);
							final byte[] mpByte = new byte[1024];
							int mpint;
							while ((mpint = mpIS.read(mpByte)) != -1) {
								mpFOS.write(mpByte, 0, mpint); } 
							mpIS.close();
							mpFOS.close();
						} catch (Exception e) {} }
					mp = MediaPlayer.create(getApplicationContext(), Uri.fromFile(new java.io.File(mpFile.getAbsolutePath())));
					mp.start();
				}
			}
		});
	}
	
	private void initializeLogic() {
		current = 0;
		linear2.setVisibility(View.GONE);
		{
			android.graphics.drawable.GradientDrawable PLUGIN = new android.graphics.drawable.GradientDrawable();
			PLUGIN.setColor(0xFFFFFFFF);linear3.setElevation(getDip(5));
			android.graphics.drawable.RippleDrawable PLUGIN_RD = new android.graphics.drawable.RippleDrawable(new android.content.res.ColorStateList(new int[][]{new int[]{}}, new int[]{0xFFE0E0E0}), PLUGIN, null);
			linear3.setBackground(PLUGIN_RD);
		}
		{
			android.graphics.drawable.GradientDrawable PLUGIN = new android.graphics.drawable.GradientDrawable();
			PLUGIN.setColor(0xFFFFFFFF);float lt = getDip(20);
			float rt = getDip(20);
			float rb = getDip(0);
			float lb = getDip(0);
			PLUGIN.setCornerRadii(new float[]{
					lt,lt,rt ,rt,rb,rb ,lb,lb });
			linear2.setElevation(getDip(5));
			android.graphics.drawable.RippleDrawable PLUGIN_RD = new android.graphics.drawable.RippleDrawable(new android.content.res.ColorStateList(new int[][]{new int[]{}}, new int[]{0xFFE0E0E0}), PLUGIN, null);
			linear2.setBackground(PLUGIN_RD);
		}
		String name = this.getString(R.string.app_name);
		textview1.setText(name);
		_NavStatusBarColor("#FFFFFF", "#FFFFFF");
		AssetManager listA = getAssets();
		try {
			String[] listS = listA.list("");
			list = new ArrayList<String>(Arrays.asList(listS));
		}catch(Exception e){}
		nr = 0;
		for(int _repeat40 = 0; _repeat40 < (int)(list.size()); _repeat40++) {
			if (list.get((int)(nr)).equals("images") || list.get((int)(nr)).equals("webkit")) {
				nr++;
			}
			else {
				{
					HashMap<String, Object> _item = new HashMap<>();
					_item.put("path", list.get((int)(nr)));
					listmap.add(_item);
				}
				
				nr++;
			}
		}
		listview1.setAdapter(new Listview1Adapter(listmap));
		((BaseAdapter)listview1.getAdapter()).notifyDataSetChanged();
	}
	
	public void _NavStatusBarColor(final String _color1, final String _color2) {
		if (Build.VERSION.SDK_INT > Build.VERSION_CODES.LOLLIPOP) {
			Window w = this.getWindow();	w.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);	w.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
			w.setStatusBarColor(Color.parseColor("#" + _color1.replace("#", "")));	w.setNavigationBarColor(Color.parseColor("#" + _color2.replace("#", "")));
		}
	}
	
	
	public void _save_assets_folder(final String _path, final String _save_path) {
		new CustomAssetsManager(MusActivity.this).saveFolder(_path,_save_path);
	}
	
	
	public void _extra() {
	}
	
	public static class CustomAssetsManager {
		    
		private Context myContext;
		    
		public CustomAssetsManager(Context c) {
			    myContext = c;
			    
		}
		
		public CustomAssetsManager(Fragment f) {
			    myContext = f.getActivity();
			    
		}
		
		public CustomAssetsManager(DialogFragment df) {
			    myContext = df.getActivity();
			    
		}
		
		public void saveFile(String path , String pathTo) {
			    copyFile(path,pathTo);
			    
		}
		
		public void saveFolder(String path , String pathTo) {
			    copyAssets(path,pathTo);
		}
		
		private void copyAssets(final String _folder , final String _to) {
			    AssetManager assetManager = myContext.getAssets();
			    String[] files = null;
			    try {
				        files = assetManager.list(_folder);
				    } catch (java.io.IOException e) {
				        Log.e("tag", "Failed to get asset file list.", e);
				    }
			    if (files != null) for (String filename : files) {
				        java.io.InputStream in = null;
				        java.io.OutputStream out = null;
				        try {
					          in = assetManager.open(_folder + "/" +filename);
					          if(!new java.io.File(_to).exists()) {
						              new java.io.File(_to).mkdir();
						              
						          java.io.File outFile = new java.io.File(_to, filename);
						          if (!(outFile.exists())) {// File does not exist...
							                out = new java.io.FileOutputStream(outFile);
							                copyFile(in, out);
							          }
						              
						          } else {
						              
						          java.io.File outFile = new java.io.File(_to, filename);
						          if (!(outFile.exists())) {// File does not exist...
							                out = new java.io.FileOutputStream(outFile);
							                copyFile(in, out);
							          }
						          }
					        } catch(java.io.IOException e) {
					            Log.e("tag", "Failed to copy asset file: " + filename, e);
					        }     
				        finally {
					            if (in != null) {
						                try {
							                    in.close();
							                } catch (java.io.IOException e) {
							                    // NOOP
							                }
						            }
					            if (out != null) {
						                try {
							                    out.close();
							                } catch (java.io.IOException e) {
							                    // NOOP
							                }
						            }
					        }  
				    }
		}
		private void copyFile(java.io.InputStream in, java.io.OutputStream out) throws java.io.IOException {
			    byte[] buffer = new byte[1024];
			    int read;
			    while((read = in.read(buffer)) != -1){
				      out.write(buffer, 0, read);
				    }
		}
		
		private void copyFile(String filename, String outPath) {
			    AssetManager assetManager = myContext.getAssets();
			
			    java.io.InputStream in;
			    java.io.OutputStream out;
			    try {
				        in = assetManager.open(filename);
				        String newFileName = outPath + "/" + filename;
				        out = new java.io.FileOutputStream(newFileName);
				
				        byte[] buffer = new byte[1024];
				        int read;
				        while ((read = in.read(buffer)) != -1) {
					            out.write(buffer, 0, read);
					        }
				        in.close();
				        out.flush();
				        out.close();
				    } catch (Exception e) {
				    }
			
		}
	}
	{
	}
	
	
	public void _getFileList(final String _fromPath) {
		list.clear();
		listmap.clear();
		FileUtil.listDir(_fromPath, list);
		nr = 0;
		for(int _repeat15 = 0; _repeat15 < (int)(list.size()); _repeat15++) {
			{
				HashMap<String, Object> _item = new HashMap<>();
				_item.put("path", list.get((int)(nr)));
				listmap.add(_item);
			}
			
			nr++;
		}
		currentFilePath = _fromPath;
		listview1.setAdapter(new Listview1Adapter(listmap));
		((BaseAdapter)listview1.getAdapter()).notifyDataSetChanged();
	}
	
	public class Listview1Adapter extends BaseAdapter {
		
		ArrayList<HashMap<String, Object>> _data;
		
		public Listview1Adapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public int getCount() {
			return _data.size();
		}
		
		@Override
		public HashMap<String, Object> getItem(int _index) {
			return _data.get(_index);
		}
		
		@Override
		public long getItemId(int _index) {
			return _index;
		}
		
		@Override
		public View getView(final int _position, View _v, ViewGroup _container) {
			LayoutInflater _inflater = (LayoutInflater) getBaseContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
			View _view = _v;
			if (_view == null) {
				_view = _inflater.inflate(R.layout.uio, null);
			}
			
			final LinearLayout linear1 = _view.findViewById(R.id.linear1);
			final LinearLayout linear2 = _view.findViewById(R.id.linear2);
			final ImageView imageview1 = _view.findViewById(R.id.imageview1);
			final TextView textview1 = _view.findViewById(R.id.textview1);
			
			{
				android.graphics.drawable.GradientDrawable PLUGIN = new android.graphics.drawable.GradientDrawable();
				PLUGIN.setColor(0xFFFFFFFF);PLUGIN.setCornerRadius(getDip(10));
				linear1.setElevation(getDip(5));
				android.graphics.drawable.RippleDrawable PLUGIN_RD = new android.graphics.drawable.RippleDrawable(new android.content.res.ColorStateList(new int[][]{new int[]{}}, new int[]{0xFFE0E0E0}), PLUGIN, null);
				linear1.setBackground(PLUGIN_RD);
			}
			textview1.setText(listmap.get((int)_position).get("path").toString().replace(".mp3", ""));
			
			return _view;
		}
	}
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input) {
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels() {
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels() {
		return getResources().getDisplayMetrics().heightPixels;
	}
}