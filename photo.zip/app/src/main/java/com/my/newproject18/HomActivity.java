package com.my.newproject18;

import android.app.Activity;
import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.io.*;
import java.util.*;
import java.util.regex.*;
import java.text.*;
import org.json.*;
import java.util.ArrayList;
import java.util.HashMap;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.ImageView;
import android.content.Intent;
import android.net.Uri;
import android.app.Fragment;
import android.app.FragmentManager;
import android.app.DialogFragment;
import android.Manifest;
import android.content.pm.PackageManager;

public class HomActivity extends Activity {
	
	private double nr = 0;
	private String currentFilePath = "";
	private String name = "";
	
	private ArrayList<HashMap<String, Object>> k = new ArrayList<>();
	private ArrayList<String> list = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> listmap = new ArrayList<>();
	
	private LinearLayout linear1;
	private LinearLayout linear2;
	private LinearLayout linear3;
	private TextView textview1;
	private ImageView imageview1;
	private GridView gridview1;
	
	private Intent i = new Intent();
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.hom);
		initialize(_savedInstanceState);
		
		if (Build.VERSION.SDK_INT >= 23) {
			if (checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED
			||checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED) {
				requestPermissions(new String[] {Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1000);
			} else {
				initializeLogic();
			}
		} else {
			initializeLogic();
		}
	}
	
	@Override
	public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
		super.onRequestPermissionsResult(requestCode, permissions, grantResults);
		if (requestCode == 1000) {
			initializeLogic();
		}
	}
	
	private void initialize(Bundle _savedInstanceState) {
		linear1 = findViewById(R.id.linear1);
		linear2 = findViewById(R.id.linear2);
		linear3 = findViewById(R.id.linear3);
		textview1 = findViewById(R.id.textview1);
		imageview1 = findViewById(R.id.imageview1);
		gridview1 = findViewById(R.id.gridview1);
	}
	
	private void initializeLogic() {
		{
			android.graphics.drawable.GradientDrawable PLUGIN = new android.graphics.drawable.GradientDrawable();
			PLUGIN.setColor(0xFFFFFFFF);linear2.setElevation(getDip(5));
			android.graphics.drawable.RippleDrawable PLUGIN_RD = new android.graphics.drawable.RippleDrawable(new android.content.res.ColorStateList(new int[][]{new int[]{}}, new int[]{0xFFE0E0E0}), PLUGIN, null);
			linear2.setBackground(PLUGIN_RD);
		}
		_NavStatusBarColor("#FFFFFF", "#FFFFFF");
		String name = this.getString(R.string.app_name);
		textview1.setText(name);
		FileUtil.makeDir(FileUtil.getExternalStorageDir().concat("/Apker"));
		_save_assets_folder("Photo", FileUtil.getExternalStorageDir().concat("/Apker/Photo"));
		_getFileList(FileUtil.getExternalStorageDir().concat("/Apker/Photo"));
		gridview1.setAdapter(new Gridview1Adapter(listmap));
	}
	
	public void _NavStatusBarColor(final String _color1, final String _color2) {
		if (Build.VERSION.SDK_INT > Build.VERSION_CODES.LOLLIPOP) {
			Window w = this.getWindow();	w.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);	w.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
			w.setStatusBarColor(Color.parseColor("#" + _color1.replace("#", "")));	w.setNavigationBarColor(Color.parseColor("#" + _color2.replace("#", "")));
		}
	}
	
	
	public void _save_assets_folder(final String _path, final String _save_path) {
		new CustomAssetsManager(HomActivity.this).saveFolder(_path,_save_path);
	}
	
	
	public void _extra() {
	}
	
	public static class CustomAssetsManager {
		    
		private Context myContext;
		    
		public CustomAssetsManager(Context c) {
			    myContext = c;
			    
		}
		
		public CustomAssetsManager(Fragment f) {
			    myContext = f.getActivity();
			    
		}
		
		public CustomAssetsManager(DialogFragment df) {
			    myContext = df.getActivity();
			    
		}
		
		public void saveFile(String path , String pathTo) {
			    copyFile(path,pathTo);
			    
		}
		
		public void saveFolder(String path , String pathTo) {
			    copyAssets(path,pathTo);
		}
		
		private void copyAssets(final String _folder , final String _to) {
			    AssetManager assetManager = myContext.getAssets();
			    String[] files = null;
			    try {
				        files = assetManager.list(_folder);
				    } catch (java.io.IOException e) {
				        Log.e("tag", "Failed to get asset file list.", e);
				    }
			    if (files != null) for (String filename : files) {
				        java.io.InputStream in = null;
				        java.io.OutputStream out = null;
				        try {
					          in = assetManager.open(_folder + "/" +filename);
					          if(!new java.io.File(_to).exists()) {
						              new java.io.File(_to).mkdir();
						              
						          java.io.File outFile = new java.io.File(_to, filename);
						          if (!(outFile.exists())) {// File does not exist...
							                out = new java.io.FileOutputStream(outFile);
							                copyFile(in, out);
							          }
						              
						          } else {
						              
						          java.io.File outFile = new java.io.File(_to, filename);
						          if (!(outFile.exists())) {// File does not exist...
							                out = new java.io.FileOutputStream(outFile);
							                copyFile(in, out);
							          }
						          }
					        } catch(java.io.IOException e) {
					            Log.e("tag", "Failed to copy asset file: " + filename, e);
					        }     
				        finally {
					            if (in != null) {
						                try {
							                    in.close();
							                } catch (java.io.IOException e) {
							                    // NOOP
							                }
						            }
					            if (out != null) {
						                try {
							                    out.close();
							                } catch (java.io.IOException e) {
							                    // NOOP
							                }
						            }
					        }  
				    }
		}
		private void copyFile(java.io.InputStream in, java.io.OutputStream out) throws java.io.IOException {
			    byte[] buffer = new byte[1024];
			    int read;
			    while((read = in.read(buffer)) != -1){
				      out.write(buffer, 0, read);
				    }
		}
		
		private void copyFile(String filename, String outPath) {
			    AssetManager assetManager = myContext.getAssets();
			
			    java.io.InputStream in;
			    java.io.OutputStream out;
			    try {
				        in = assetManager.open(filename);
				        String newFileName = outPath + "/" + filename;
				        out = new java.io.FileOutputStream(newFileName);
				
				        byte[] buffer = new byte[1024];
				        int read;
				        while ((read = in.read(buffer)) != -1) {
					            out.write(buffer, 0, read);
					        }
				        in.close();
				        out.flush();
				        out.close();
				    } catch (Exception e) {
				    }
			
		}
	}
	{
	}
	
	
	public void _getFileList(final String _fromPath) {
		list.clear();
		listmap.clear();
		FileUtil.listDir(_fromPath, list);
		nr = 0;
		for(int _repeat15 = 0; _repeat15 < (int)(list.size()); _repeat15++) {
			{
				HashMap<String, Object> _item = new HashMap<>();
				_item.put("path", list.get((int)(nr)));
				listmap.add(_item);
			}
			
			nr++;
		}
		currentFilePath = _fromPath;
		gridview1.setAdapter(new Gridview1Adapter(listmap));
	}
	
	public class Gridview1Adapter extends BaseAdapter {
		
		ArrayList<HashMap<String, Object>> _data;
		
		public Gridview1Adapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public int getCount() {
			return _data.size();
		}
		
		@Override
		public HashMap<String, Object> getItem(int _index) {
			return _data.get(_index);
		}
		
		@Override
		public long getItemId(int _index) {
			return _index;
		}
		
		@Override
		public View getView(final int _position, View _v, ViewGroup _container) {
			LayoutInflater _inflater = (LayoutInflater) getBaseContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
			View _view = _v;
			if (_view == null) {
				_view = _inflater.inflate(R.layout.pho, null);
			}
			
			final LinearLayout linear2 = _view.findViewById(R.id.linear2);
			final ImageView imageview1 = _view.findViewById(R.id.imageview1);
			
			imageview1.setImageBitmap(FileUtil.decodeSampleBitmapFromPath(listmap.get((int)_position).get("path").toString(), 1024, 1024));
			{
				android.graphics.drawable.GradientDrawable PLUGIN = new android.graphics.drawable.GradientDrawable();
				PLUGIN.setColor(0xFFFFFFFF);linear2.setElevation(getDip(5));
				android.graphics.drawable.RippleDrawable PLUGIN_RD = new android.graphics.drawable.RippleDrawable(new android.content.res.ColorStateList(new int[][]{new int[]{}}, new int[]{0xFFE0E0E0}), PLUGIN, null);
				linear2.setBackground(PLUGIN_RD);
			}
			linear2.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View _view) {
					i.putExtra("path", listmap.get((int)_position).get("path").toString());
					i.setClass(getApplicationContext(), ViwActivity.class);
					startActivity(i);
				}
			});
			
			return _view;
		}
	}
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input) {
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels() {
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels() {
		return getResources().getDisplayMetrics().heightPixels;
	}
}