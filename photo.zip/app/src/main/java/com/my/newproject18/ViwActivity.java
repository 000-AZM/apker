package com.my.newproject18;

import android.app.Activity;
import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.io.*;
import java.util.*;
import java.util.regex.*;
import java.text.*;
import org.json.*;
import android.widget.LinearLayout;
import android.widget.ImageView;
import android.widget.Button;
import android.view.View;
import android.app.Fragment;
import android.app.FragmentManager;
import android.app.DialogFragment;
import android.Manifest;
import android.content.pm.PackageManager;

public class ViwActivity extends Activity {
	
	private String tgfile = "";
	
	private LinearLayout linear1;
	private LinearLayout linear2;
	private LinearLayout linear3;
	private ImageView imageview1;
	private LinearLayout linear5;
	private Button button1;
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.viw);
		initialize(_savedInstanceState);
		
		if (Build.VERSION.SDK_INT >= 23) {
			if (checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED
			||checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED) {
				requestPermissions(new String[] {Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1000);
			} else {
				initializeLogic();
			}
		} else {
			initializeLogic();
		}
	}
	
	@Override
	public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
		super.onRequestPermissionsResult(requestCode, permissions, grantResults);
		if (requestCode == 1000) {
			initializeLogic();
		}
	}
	
	private void initialize(Bundle _savedInstanceState) {
		linear1 = findViewById(R.id.linear1);
		linear2 = findViewById(R.id.linear2);
		linear3 = findViewById(R.id.linear3);
		imageview1 = findViewById(R.id.imageview1);
		linear5 = findViewById(R.id.linear5);
		button1 = findViewById(R.id.button1);
		
		button1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				
			}
		});
	}
	
	private void initializeLogic() {
		_NavStatusBarColor("#FFFFFF", "#FFFFFF");
		tgfile = "/Pictures/APKER/";
		imageview1.setImageBitmap(FileUtil.decodeSampleBitmapFromPath(getIntent().getStringExtra("path"), 1024, 1024));
		if (!FileUtil.isExistFile(FileUtil.getExternalStorageDir().concat(tgfile))) {
			FileUtil.makeDir(FileUtil.getExternalStorageDir().concat(tgfile));
		}
		zoomLinearLayout = new ZoomableLinearLayout(ViwActivity.this);
		linear2.removeView(linear3);
		linear1.removeView(linear2);
		zoomLinearLayout.addView(linear3);
		linear3.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT,LinearLayout.LayoutParams.MATCH_PARENT));
		zoomLinearLayout.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT,LinearLayout.LayoutParams.MATCH_PARENT));
		linear1.addView(zoomLinearLayout);
	}
	
	public void _NavStatusBarColor(final String _color1, final String _color2) {
		if (Build.VERSION.SDK_INT > Build.VERSION_CODES.LOLLIPOP) {
			Window w = this.getWindow();	w.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);	w.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
			w.setStatusBarColor(Color.parseColor("#" + _color1.replace("#", "")));	w.setNavigationBarColor(Color.parseColor("#" + _color2.replace("#", "")));
		}
	}
	
	
	public void _saveImage(final View _view, final String _path, final String _name) {
		Bitmap returnedBitmap = Bitmap.createBitmap(_view.getWidth(), _view.getHeight(),Bitmap.Config.ARGB_8888);
		Canvas canvas = new Canvas(returnedBitmap); 
		android.graphics.drawable.Drawable bgDrawable =_view.getBackground(); 
		if (bgDrawable!=null) { 
				bgDrawable.draw(canvas); 
			} else { 
					canvas.drawColor(Color.WHITE); 
			}
		_view.draw(canvas); 
		java.io.File pictureFile = new java.io.File(Environment.getExternalStorageDirectory() + _path + _name +".png"); 
		if (pictureFile == null) {
				showMessage("Error creating media file, check storage permissions: "); 
				return; 
			}
		try { 
				java.io.FileOutputStream fos = new java.io.FileOutputStream(pictureFile); 
				returnedBitmap.compress(Bitmap.CompressFormat.PNG, 100, fos);
				fos.close();
			} catch (java.io.FileNotFoundException e) { 
					showMessage("File not found: " + e.getMessage()); 
				} catch (java.io.IOException e) { 
						showMessage("Error accessing file: " + e.getMessage()); 
				}
		sendBroadcast(new Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE, Uri.fromFile(pictureFile)));
	}
	
	
	public void _variableName() {
	}
	private ZoomableLinearLayout zoomLinearLayout;
	{
	}
	
	
	public void _library() {
	}
	public static class ZoomableLinearLayout extends LinearLayout implements ScaleGestureDetector.OnScaleGestureListener {
		
		    private enum Mode {
			        NONE,
			        DRAG,
			        ZOOM
			    }
		
		    private static final float MIN_ZOOM = 1.0f;
		    private static final float MAX_ZOOM = 4.0f;
		
		    private Mode mode = Mode.NONE;
		    private float scale = 1.0f;
		    private float lastScaleFactor = 0f;
		
		    private float startX = 0f;
		    private float startY = 0f;
		
		    private float dx = 0f;
		    private float dy = 0f;
		    private float prevDx = 0f;
		    private float prevDy = 0f;
		
		    public ZoomableLinearLayout(Context context) {
			        super(context);
			        init(context);
			    }
		
		    public void init(Context context) {
			        final ScaleGestureDetector scaleDetector = new ScaleGestureDetector(context, this);
			        this.setOnTouchListener(new OnTouchListener() {
				            @Override
				            public boolean onTouch(View view, MotionEvent motionEvent) {
					                switch (motionEvent.getAction() & MotionEvent.ACTION_MASK) {
						                    case MotionEvent.ACTION_DOWN:
						                        if (scale > MIN_ZOOM) {
							                            mode = Mode.DRAG;
							                            startX = motionEvent.getX() - prevDx;
							                            startY = motionEvent.getY() - prevDy;
							                        }
						                        break;
						                    case MotionEvent.ACTION_MOVE:
						                        if (mode == Mode.DRAG) {
							                            dx = motionEvent.getX() - startX;
							                            dy = motionEvent.getY() - startY;
							                        }
						                        break;
						                    case MotionEvent.ACTION_POINTER_DOWN:
						                        mode = Mode.ZOOM;
						                        break;
						                    case MotionEvent.ACTION_POINTER_UP:
						                        mode = Mode.DRAG;
						                        break;
						                    case MotionEvent.ACTION_UP:
						                        mode = Mode.NONE;
						                        prevDx = dx;
						                        prevDy = dy;
						                        break;
						                }
					                scaleDetector.onTouchEvent(motionEvent);
					
					                if ((mode == Mode.DRAG && scale >= MIN_ZOOM) || mode == Mode.ZOOM) {
						                    getParent().requestDisallowInterceptTouchEvent(true);
						                    float maxDx = (child().getWidth() - (child().getWidth() / scale)) / 2 * scale;
						                    float maxDy = (child().getHeight() - (child().getHeight() / scale)) / 2 * scale;
						                    dx = Math.min(Math.max(dx, -maxDx), maxDx);
						                    dy = Math.min(Math.max(dy, -maxDy), maxDy);
						                    applyScaleAndTranslation();
						                }
					
					                return true;
					            }
				        });
			    }
		
		    @Override
		    public boolean onScaleBegin(ScaleGestureDetector scaleDetector) {
			        return true;
			    }
		
		    @Override
		    public boolean onScale(ScaleGestureDetector scaleDetector) {
			        float scaleFactor = scaleDetector.getScaleFactor();
			        if (lastScaleFactor == 0 || (Math.signum(scaleFactor) == Math.signum(lastScaleFactor))) {
				            scale *= scaleFactor;
				            scale = Math.max(MIN_ZOOM, Math.min(scale, MAX_ZOOM));
				            lastScaleFactor = scaleFactor;
				        } else {
				            lastScaleFactor = 0;
				        }
			        return true;
			    }
		
		    @Override
		    public void onScaleEnd(ScaleGestureDetector scaleDetector) {
			    }
		
		    private void applyScaleAndTranslation() {
			        child().setScaleX(scale);
			        child().setScaleY(scale);
			        child().setTranslationX(dx);
			        child().setTranslationY(dy);
			    }
		
		    private View child() {
			        return getChildAt(0);
			    }
	}
	
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input) {
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels() {
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels() {
		return getResources().getDisplayMetrics().heightPixels;
	}
}